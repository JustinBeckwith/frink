
/*--------------------------------------------------------------------------
--
-- LOAD EVENTS
--
--------------------------------------------------------------------------*/


$(document).ready(function(e) {
	
	/**
	 *	show the about window
	 **/
	$("#btnAbout").fancybox({
		showCloseButton: false,
		title: 'About Frink!'
	});
	
});
